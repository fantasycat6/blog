<html>
<body>
<?php echo @readfile($_REQUEST['url']); ?>
</body>
</html>
